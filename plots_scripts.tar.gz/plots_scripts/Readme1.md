DATA SOURCES:- 
 the data is taken from the agricultural catalogs of the Open Govt Data(OGD) platform India
and the link is https://data.gov.in/catalogs/sector/Agriculture-9212

PLOTS:-
1. barplot_fig.png shows the plot between "no of private companies" that shares their "Economic Activity" for 
   various sectors such as agricultures,industry and services.
2. scatterplot_fig.png shows the plots of "Authorized Capital - Private" and "no of private companies" that shares their "Economic Activity" for 
   various sectors such as agricultures,industry and services.
3. boxplot_fig.png show the logarithmic plot of "Authorized Capital - Public" and "Authorized Capital - Private" that shares their "Economic Activity" for 
   various sectors such as agricultures,industry and services. 


USEFUL LINKS:-
1.https://data.gov.in
2.https://github.com/simmhan/probable-bassoon
